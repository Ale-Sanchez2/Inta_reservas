# Aplicación Restaurante
Restaurante | ConfiguroWeb es una aplicación web que gestiona el orden del menú del restaurante entre el perfil mesero y el chef.

## Acceso Admin
Usuario "admin"
Contraseña "1234abcd.."

Para ver los empleados:
Busca en la BD




### Nota
All staff created have same default password : 1234abcd..
